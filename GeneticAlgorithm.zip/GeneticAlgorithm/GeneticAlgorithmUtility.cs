using System;
using System.Collections.Specialized;
using System.Runtime.InteropServices;

namespace GeneticAlgorithms
{
	/// <summary>
	/// Provides static methods that assist the base Genetic Algorithm and implementors of it's interfaces.
	/// </summary>
	public sealed class GeneticAlgorithmUtility
	{

		private GeneticAlgorithmUtility() {}

		#region Serializer Methods
		// Original creator:
		// 9/28/2002
		// NETMaster (Thomas Scheidegger)
		//	http://www.cetus-links.org/oo_csharp.html
		public static object RawDeserializeEx( byte[] rawdatas, Type anytype, int rawsize)
		{
//			int rawsize = Marshal.SizeOf( anytype );
//			if( rawsize > rawdatas.Length )
//				return null;
			GCHandle handle = GCHandle.Alloc( rawdatas, GCHandleType.Pinned );
			IntPtr buffer = handle.AddrOfPinnedObject();
			object retobj = Marshal.PtrToStructure( buffer, anytype );
			handle.Free();
			return retobj;
		}


		public static byte[] RawSerializeEx(object anything, int rawsize)
		{
			//int rawsize = Marshal.SizeOf( anything );
			byte[] rawdatas = new byte[ rawsize ];
			GCHandle handle = GCHandle.Alloc( rawdatas, GCHandleType.Pinned );
			IntPtr buffer = handle.AddrOfPinnedObject();
			Marshal.StructureToPtr( anything, buffer, false );
			handle.Free();
			return rawdatas;
		}

		#endregion

		#region Gray Code Methods
		/// <summary>
		/// Holds the flags necessary to access the BitVector32's members.
		/// </summary>
		private static int[] bvflags=new int[32];

		/// <summary>
		/// Static constructor creates the mask flags used by the BitVector32 to access individual bits
		/// of the int.
		/// </summary>
		static GeneticAlgorithmUtility()
		{
			bvflags[0] = BitVector32.CreateMask();
			for(int i=1;i<32;i++)
				bvflags[i] = BitVector32.CreateMask(bvflags[i-1]);
		}

		/// <summary>
		/// Converts an int value from normal .NET representation to a Gray code int.
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public static int ToGrayCode(int value)
		{
			return ToGrayCode(new BitVector32(value));
		}


		/// <summary>
		/// Converts a BitVector32 represention a .NET int to a Gray code int.
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public static int ToGrayCode(BitVector32 value)
		{
			BitVector32 rValue = new BitVector32(0);
			// set highest-order bit:
			rValue[31] = value[31];

			// now go from high to low order bit and XOR
			// on the normally encoded bit and the one
			// previous (higher-order) to it:
			for(int i=30;i>=0;i--)
			{
				rValue[bvflags[i]] = value[bvflags[i+1]]^value[bvflags[i]];
			}

			return rValue.Data;
		}


		/// <summary>
		/// Converts a Gray coded int to .NET int. 
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public static int FromGrayCode(int value)
		{
			return FromGrayCode(new BitVector32(value));
		}

		/// <summary>
		/// Converts a BitVector32 representing a Gray code int to a .NET int.
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public static int FromGrayCode(BitVector32 value)
		{
			BitVector32 rValue = new BitVector32(0);
			// set highest-order bit:
			rValue[31] = value[31];

			// now go from high to low order bit and XOR
			// on the normally encoded bit and the one
			// previous (higher-order) to it:
			for(int i=30;i>=0;i--)
			{
				rValue[bvflags[i]] = rValue[bvflags[i+1]]^value[bvflags[i]];
			}

			return rValue.Data;
		}
		#endregion

		#region Random Methods
		public static byte[] GetRandomBytes(int size)
		{
			byte[] buffer=new byte[size];
			RandomProvider.NextBytes(buffer);
			return buffer;
		}

		private static Random _randomProvider=new Random();
		public static Random RandomProvider
		{
			get
			{
				return _randomProvider;
			}
			set
			{
				_randomProvider=value;
			}
		}
		#endregion
	}
}



