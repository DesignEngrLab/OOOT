using System;

namespace GeneticAlgorithms
{
	public class RandomSelector : IGenomeSelector
	{
		public RandomSelector(GenomeCollection genomes)
		{
			_genomes=genomes;
		}

		#region IGenomeSelector Members
		private GenomeCollection _genomes;
		public GenomeCollection Genomes
		{
			get
			{
				return _genomes;
			}
			set
			{
				_genomes=value;
			}
		}

		public Genome Select()
		{			
				return _genomes[GeneticAlgorithmUtility.RandomProvider.Next(_genomes.Count-1)];
		}
		#endregion
	}
}
