using System;
using System.Runtime.InteropServices;
using GeneticAlgorithms;
using GeneticAlgorithms.Binary;

namespace Example1
{
	public class GrayEvaluator : IEvaluateGenome
	{
		#region IEvaluateGenome Members
		public double Eval(Genome candidate)
		{			
			SimpleSolution sol = (SimpleSolution)((BinaryGenome)candidate).GetObject();
			int a = GeneticAlgorithmUtility.FromGrayCode(sol.value1);
			int b = GeneticAlgorithmUtility.FromGrayCode(sol.value2);
			int c = GeneticAlgorithmUtility.FromGrayCode(sol.value3);
			
			// fitness is simply a larger number for:
			return 100 * (((double)a) + ((double)b) + ((double)c)) / (((double)int.MaxValue) * 3);
		}
		#endregion
	}
}
