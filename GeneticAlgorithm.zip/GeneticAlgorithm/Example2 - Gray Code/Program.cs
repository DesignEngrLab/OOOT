using System;
using GeneticAlgorithms;
using GeneticAlgorithms.Binary;

namespace Example1
{
	/// <summary>
	/// Summary description for Program.
	/// </summary>
	public class Program
	{
		public static void Main()
		{
            GeneticAlgorithm ga = new GeneticAlgorithm();

			ga.Selector = new WeightedSelector(ga.Genomes);
			ga.Crossover = new BinaryCrossover();
			((BinaryCrossover)ga.Crossover).CrossoverProbability = 0.2;
			((BinaryCrossover)ga.Crossover).MutationProbability = 0.07;
			ga.GenomeFactory = new BinaryGenomeFactory(typeof(SimpleSolution));
			ga.Evaluator = new GrayEvaluator();

			ga.NewGlobalBest += new GeneticAlgorithmEventHandler(onNewGBest);

			ga.CreateGenomes(18);

			ExitConditions whenToQuit = new ExitConditions();
			whenToQuit.Duration = new TimeSpan(0, 0, 10);
			whenToQuit.Generations = 24000;


			Counter clock = new Counter();
			clock.Start();
			Genome maxima = ga.FindOptima(whenToQuit);
			clock.Stop();

			Console.WriteLine(maxima.Fitness.ToString("n"));
			Console.WriteLine(((BinaryGenome)maxima).GetObject());
			Console.WriteLine("Time: {0:n}\tGenerations: {1}", clock.Seconds, ga.GenerationCount);			
			Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

#if DEBUG
			Console.ReadLine();
#endif
   		
		}	
		
		public static void onNewGBest(GeneticAlgorithm sender, EventArgs args)
		{			
			Console.WriteLine("New GBest: {0}\t\t Generation {1}", sender.Genomes[sender.Genomes.Count-1].Fitness, sender.GenerationCount);
		}
	}
}
