using System;

namespace Example4___NonTrivial_Real
{
	public enum FitnessFunctionMode
	{
		Spherical,
		Rosenbrock,
		Rastrigrin
	}
}
