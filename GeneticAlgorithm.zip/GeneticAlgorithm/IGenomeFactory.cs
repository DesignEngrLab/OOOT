using System;

namespace GeneticAlgorithms
{
	/// <summary>
	/// Collects methods used to create Genomes
	/// </summary>
	public interface IGenomeFactory
	{
		Genome CreateGenome(GeneticAlgorithm parent);
	}
}
