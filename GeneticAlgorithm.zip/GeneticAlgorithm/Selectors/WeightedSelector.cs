using System;

namespace GeneticAlgorithms
{
	public class WeightedSelector : IGenomeSelector
	{
		public WeightedSelector(GenomeCollection genomes)
		{
			_genomes=genomes;
		}

		#region IGenomeSelector Members
		private GenomeCollection _genomes;
		public GenomeCollection Genomes
		{
			get
			{
				return _genomes;
			}
			set
			{
				_genomes=value;
			}
		}

		public Genome Select()
		{			
			int selectedIndex=-1;
						
			int searchSpaceStart=0;
			int searchSpaceEnd=_genomes.Count-1;
			int currentSearchNode = (searchSpaceEnd/2);
			// the random chance scaled to 0 - largest fitness value):

			// There must be a dif in Fitness between the greatest and least, or we just return a 
			// random genome.
			if((_genomes[searchSpaceEnd].Fitness - _genomes[0].Fitness)==0)
				return _genomes[GeneticAlgorithmUtility.RandomProvider.Next(_genomes.Count-1)];

			double scaledProbability = (GeneticAlgorithmUtility.RandomProvider.NextDouble() * (_genomes[searchSpaceEnd].Fitness - _genomes[0].Fitness))+_genomes[0].Fitness;

			// faster then BinarySearch
			while(selectedIndex==-1)
			{
				// move 
				if(scaledProbability<_genomes[currentSearchNode].Fitness)
				{
					searchSpaceEnd = currentSearchNode;
				}
				else
				{
					searchSpaceStart = currentSearchNode;
				}
				currentSearchNode = (searchSpaceStart+searchSpaceEnd)/2;

				if((searchSpaceEnd-searchSpaceStart)==1)
               selectedIndex=searchSpaceEnd;        
			}
         return _genomes[selectedIndex];
		}

		#endregion
	}
}
