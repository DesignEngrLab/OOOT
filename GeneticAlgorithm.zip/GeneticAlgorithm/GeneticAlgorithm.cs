using System;
using System.Runtime.InteropServices;

namespace GeneticAlgorithms
{
	/// <summary>
	/// The GeneticAlgorithm class is the cornerstone in a small framework of class that build a customizable
	/// genetic algorithm searches.  At a mimimum you must set up either a BinaryGenome or RealGenome 
	/// that describes a solution to your problem and then  implement the IEvaluateGenome interface to 
	/// provide a way of 'scoring' each possible candidate in the population of possible solutions.
	/// 
	/// See the provided examples for more information.
	/// </summary>
	public class GeneticAlgorithm
	{
		protected internal readonly System.Type genomeType;

	
		/// <summary>
		/// Creates an instance of the GeneticAlgorithm class.
		/// </summary>
		public GeneticAlgorithm()
		{

		}

		#region Methods
		/// <summary>
		/// After you have created the GeneticAlgorithm instance and provided it with an implementation of 
		/// IGenomeFactory, this method can be called to actually create the population of custom Genomes for 
		/// use in the GA search.
		/// 
		/// In the case of the provided RealGenomeFactory you create a RealGenomeFactory instance, then
		/// set the minimum and maximum values you want each genome to have, then provide the Genetic Algorithm 
		/// the factory through the GenomeFactory property.
		/// 
		/// The GenomeFactory that you provide is responsible for every aspect of constructing the Genome so that it's ready
		/// to evaluate and crossover with over genomes.
		/// </summary>
		/// <param name="populationSize"></param>
		public void CreateGenomes(int populationSize)
		{
			if(GenomeFactory==null)
				throw new ApplicationException("Cannot create Genomes if the GenomeFactory is null");

			Genome[] genomes = new Genome[populationSize];
			for(int i=0;i<populationSize;i++)
				_genomes.Add(GenomeFactory.CreateGenome(this));
		}

		/// <summary>
		/// Attempts to find an optimal solution to the problem.
		/// </summary>
		/// <returns></returns>
		public virtual Genome FindOptima() 
		{
         return FindOptima(ExitConditions);			
		}

		/// <summary>
		/// Attempts to find an optimal solution to the problem by beginning the process of evaluation and crossover/mutation.
		/// 
		/// This method behavior is as follows: While the ExitConditions are not met, loop through each Genome in the population, and select
		/// for it a mate with (if in greedy mode, do not mate and replace the best solution with a child; keep the best solution only as 
		/// a mate for other Genomes).  Use the provided Selector to control the selection process (weighted random, or sequential etc)
		/// . Use the Crossover provided to recombine the selected genome and it's mate, as well as any mutation that must happen to the 
		/// </summary>
		/// <param name="conditions"></param>
		/// <returns></returns>
		public virtual Genome FindOptima(ExitConditions conditions)
		{
		/// If you run the debug version, the app keeps track of the time spent evaluating the Genomes
		/// recombining and mutating the Genomes (crossover) and selecting mates for the Genomes (selection)
#if DEBUG
			Counter evalTime=new Counter();
			Counter crossoverTime=new Counter();
			Counter selectorTime=new Counter();
#endif

			if(Selector==null)
				throw new ApplicationException("Cannot run FindOptima if the Selector is null");

			if(Crossover==null)
				throw new ApplicationException("Cannot run FindOptima if the Crossover is null");

			startTime=DateTime.Now;

			// this is how greedyness is implemented:
			// if we are 'greedy' we keep the top genome every time, so we short the 
			// count or genomes by one, because we want the last genome to remain
			// untouched
			int genomeCount = (IsGreedy ? _genomes.Count-1 : _genomes.Count);

			while(conditions.DoesContinue(this))
			{				
				 if(NewGeneration!=null)
					NewGeneration(this, null);
				#if DEBUG 
				evalTime.Start();
				#endif
				// first, evalute the fitness:
				for(int g=0;g<genomeCount;g++)
				{
					Genomes[g].Fitness = Evaluator.Eval(Genomes[g]);
				}
				#if DEBUG
				evalTime.Stop();
				#endif

				// sort places genomes in order from least fit at position 0 
				//to most fit at the end of the collection:
				Genomes.Sort();	
			
				if(Genomes[Genomes.Count-1].Fitness>_gbestFitness)
				{
					_gbestFitness=Genomes[Genomes.Count-1].Fitness;
					if(NewGlobalBest!=null)
						NewGlobalBest(this, null);
				}

				for(int g=0;g<genomeCount;g++)
				{
					#if DEBUG
					selectorTime.Start();
					#endif

					Genome mate = Selector.Select();					
					//while(mate.Equals(Genomes[g]))
					//mate = Selector.Select();

					#if DEBUG
					selectorTime.Stop();
					#endif
					
					#if DEBUG
					crossoverTime.Start();
					#endif
					/// Note: although the Crossover method will *often* simply modify the referenced first Genome 'in-place'
					/// it makes sense to return it explicitly so that future implementations *can* create new Genome instances
					/// if it better/necessary for it's particular algorithm
					_genomes[g] = Crossover.Crossover(_genomes[g], mate);

					#if DEBUG
					crossoverTime.Stop();
					#endif
				}
                generations++;
			}

#if DEBUG
		Console.WriteLine("Evaluation time: {0}", evalTime.Seconds);
		Console.WriteLine("Crossover time: {0}", crossoverTime.Seconds);
		Console.WriteLine("Selector time: {0}", selectorTime.Seconds);
#endif
			if(!IsGreedy)
				Genomes.Sort();
			return Genomes[Genomes.Count-1];
		}
		#endregion

		#region Properties
		protected DateTime startTime;
		/// <summary>
		/// Records the time FindOptima was last called.
		/// </summary>
		public DateTime StartTime
		{
			get
			{
				return startTime;
			}
		}

		protected int generations=0;
		/// <summary>
		/// The Generation count since the last time FindOptima was called.
		/// </summary>
		public int GenerationCount
		{
			get
			{
				return generations;
			}
		}


		private GenomeCollection _genomes=new GenomeCollection();
		public GenomeCollection Genomes
		{
			get
			{
				return _genomes;
			}
		}

		private IGenomeSelector _selector;
		/// <summary>
		/// The Selector is an instance of IGenomeSelector that provides the selection strategy for the GA.
		/// </summary>
		public IGenomeSelector Selector
		{
			get
			{
				return _selector;
			}
			set
			{
				_selector=value;
			}
		}

		private IEvaluateGenome _evaluator;
		/// <summary>
		/// The IEvaluateGenome implementation that the GA will use to determine Genomes' fitness.
		/// </summary>
		public IEvaluateGenome Evaluator
		{
			get
			{
				return _evaluator;
			}
			set
			{
				_evaluator=value;
			}
		}

		private ICrossover _crossover;
		/// <summary>
		/// The ICrossover used to recombine and mutate Genomes.
		/// </summary>
		public ICrossover Crossover
		{
			get
			{
				return _crossover;
			}
			set
			{
				_crossover=value;
			}
		}

		private IGenomeFactory _genomeFactory;
		/// <summary>
		/// The IGenomeFactory used to create new genomes as necessary.
		/// </summary>
		public IGenomeFactory GenomeFactory
		{
			get
			{
				return _genomeFactory;
			}
			set
			{
				_genomeFactory=value;
			}
		}

		private ExitConditions _exitConditions=new ExitConditions();
		/// <summary>
		/// Sets/Gets the instance of ExitConditions this GA is using to determine when to quit iterating through
		/// generations.
		/// </summary>
		public ExitConditions ExitConditions 
		{
			get
			{
				return _exitConditions;
			}
			set
			{
				_exitConditions=value;
			}
		}

		private bool _isGreedy=true;
		/// <summary>
		/// 'Greedyness' in this idiom of a GeneticAlgorithm means that the algorithm always holds on to the most
		/// optimal solution yet found between generations.
		/// </summary>
		public bool IsGreedy
		{
			get
			{
				return _isGreedy;
			}
			set
			{
				_isGreedy=value;
			}
		}

		#endregion

		public event GeneticAlgorithmEventHandler NewGeneration;
		public event GeneticAlgorithmEventHandler NewGlobalBest;

		private double _gbestFitness=double.MinValue;
		
	}
}
