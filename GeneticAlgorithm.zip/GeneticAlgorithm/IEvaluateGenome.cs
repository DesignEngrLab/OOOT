using System;

namespace GeneticAlgorithms
{
	public interface IEvaluateGenome
	{
		double Eval(Genome candidate);
	}
}
