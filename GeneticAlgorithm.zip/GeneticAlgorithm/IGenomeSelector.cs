using System;

namespace GeneticAlgorithms
{
	/// <summary>
	/// Defines an interface that implementors can provide that provides selection of candidate
	/// Genomes for recombination.
	/// </summary>
	public interface IGenomeSelector
	{
		/// <summary>
		/// Holds the collection of Genomes that can be selected from.  This is just a reference
		/// to the same GenomeCollection that the GeneticAlgorithm holds, so that it's fitness
		/// values will always be up-to-date.
		/// </summary>
		GenomeCollection Genomes{ get;set; }

		/// <summary>
		/// Causes the selection of a single Genome for recombination based on the internal logic
		/// of the specific implementation of the IGenomeSelector
		/// </summary>
		/// <returns></returns>
		Genome Select();
	}
}
