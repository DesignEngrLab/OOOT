using System;
using System.Collections;
using System.Collections.Specialized;
using GeneticAlgorithms;

namespace GeneticAlgorithms.Binary
{

	/// <summary>
	/// A BinaryGenome is a single instance of a potential solution to whatever problem that you are trying to optimize
	/// using a GeneticAlgorithm.  It is generic becuase it interanally uses a byte array to store and manipulate 
	/// data.
	/// </summary>
	public class BinaryGenome : Genome, IComparable
	{
		private Type _genomeType;
		private int _size;

		public BinaryGenome(GeneticAlgorithm parent, Type genomeDataType, int size) 
			: this(parent, genomeDataType, size, GeneticAlgorithmUtility.GetRandomBytes(size)) {}

		public BinaryGenome(GeneticAlgorithm parent, Type genomeDataType, int size, byte[] initialState) : base(parent)
		{
			_genomeType = genomeDataType;
			_size=size;			
			_alleles = new BitArray(initialState);
		}

		private byte[] _data;
		public byte[] Data
		{
			get
			{
				_data = new byte[_alleles.Length / 8];
				_alleles.CopyTo(_data, 0);
				return _data;
			}			
		}

		private BitArray _alleles;
		public BitArray Bits
		{
			get
			{
				return _alleles;
			}
			set
			{
				_alleles=value;
				if((_alleles.Length % 8)!=0)
					throw new ApplicationException("Bits must be a BitArray with a length that is an whole multiple of 8.");
				_data = new byte[_alleles.Length / 8];
				_alleles.CopyTo(_data, 0);
			}
		}
     
		public virtual object GetObject()
		{			
			return GeneticAlgorithmUtility.RawDeserializeEx(Data, _genomeType, _size);
		}
	}
}
