using System;
using System.Runtime.InteropServices;

namespace GeneticAlgorithms.Binary
{
	/// <summary>
	/// Summary description for BinaryGenomeFactory.
	/// </summary>
	public class BinaryGenomeFactory : IGenomeFactory
	{
		private int _typeSize;
		private Type _type;
		public BinaryGenomeFactory(Type genomeDataType)
		{
			_type=genomeDataType;
			_typeSize = Marshal.SizeOf(_type.Assembly.CreateInstance(_type.FullName));
		}
	
		#region IGenomeFactory Members

		public Genome CreateGenome(GeneticAlgorithm parent)
		{
			return new BinaryGenome(parent, _type, _typeSize);
		}

		#endregion
	}
}
