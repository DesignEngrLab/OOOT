using System;

namespace GeneticAlgorithms.Real
{
	/// <summary>
	/// Summary description for RealGenome.
	/// </summary>
	public class RealGenome : Genome
	{
		public RealGenome(GeneticAlgorithm parent, int numberOfValues) : base(parent)
		{
			_alleles = new double[numberOfValues];
		}

		private double[] _alleles;
		public double this [int index]
		{
			get
			{
				return _alleles[index];
			}
			set
			{
				_alleles[index]=value;
				// silently corrects for out of bounds values:
				if(_alleles[index]>_maxValue)
					_alleles[index]=_maxValue;
				if(_alleles[index]<_minValue)
					_alleles[index]=_minValue;
			}
		}

		public int Length
		{
			get
			{
				return _alleles.Length;
			}
		}

      private double _maxValue=double.MaxValue;
		public double MaxValue 
		{
			get
			{
				return _maxValue;
			}
			set
			{
				_maxValue=value;
			}
		}

		private double _minValue=double.MinValue;
		public double MinValue
		{
			get
			{
				return _minValue;
			}
			set
			{
				_minValue=value;
			}
		}

		public override string ToString()
		{
			string returnValue=String.Empty;

			for(int i=0;i<Length;i++)
				returnValue += "| " + _alleles[i].ToString();

			return returnValue;
		}

	}
}
