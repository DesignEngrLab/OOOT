using System;

namespace GeneticAlgorithms
{
	/// <summary>
	/// Classes that implement this interface provide the logic to crossover (recombine) two target Genomes
	/// or Genome derived classes.  
	/// </summary>
	public interface ICrossover
	{
		Genome Crossover(Genome first, Genome second);
		double CrossoverProbability { get;set; }
		double MutationProbability { get;set; }
	}
}
