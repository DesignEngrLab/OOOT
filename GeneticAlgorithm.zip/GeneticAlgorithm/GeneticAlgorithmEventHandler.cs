using System;

namespace GeneticAlgorithms
{
	public delegate void GeneticAlgorithmEventHandler(GeneticAlgorithm sender, EventArgs args);
}
