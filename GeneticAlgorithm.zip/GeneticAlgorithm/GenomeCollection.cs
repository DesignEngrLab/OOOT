using System;
using System.Collections;

namespace GeneticAlgorithms
{
	/// <summary>
	/// A collection of elements of type Genome
	/// </summary>
	public class GenomeCollection: System.Collections.CollectionBase
	{
		/// <summary>
		/// Initializes a new empty instance of the GenomeCollection class.
		/// </summary>
		public GenomeCollection()
		{
			// empty
		}

		/// <summary>
		/// Initializes a new instance of the GenomeCollection class, containing elements
		/// copied from an array.
		/// </summary>
		/// <param name="items">
		/// The array whose elements are to be added to the new GenomeCollection.
		/// </param>
		public GenomeCollection(Genome[] items)
		{
			this.AddRange(items);
		}

		/// <summary>
		/// Initializes a new instance of the GenomeCollection class, containing elements
		/// copied from another instance of GenomeCollection
		/// </summary>
		/// <param name="items">
		/// The GenomeCollection whose elements are to be added to the new GenomeCollection.
		/// </param>
		public GenomeCollection(GenomeCollection items)
		{
			this.AddRange(items);
		}

		/// <summary>
		/// Adds the elements of an array to the end of this GenomeCollection.
		/// </summary>
		/// <param name="items">
		/// The array whose elements are to be added to the end of this GenomeCollection.
		/// </param>
		public virtual void AddRange(Genome[] items)
		{
			foreach (Genome item in items)
			{
				this.List.Add(item);
			}
		}

		/// <summary>
		/// Adds the elements of another GenomeCollection to the end of this GenomeCollection.
		/// </summary>
		/// <param name="items">
		/// The GenomeCollection whose elements are to be added to the end of this GenomeCollection.
		/// </param>
		public virtual void AddRange(GenomeCollection items)
		{
			foreach (Genome item in items)
			{
				this.List.Add(item);
			}
		}

		/// <summary>
		/// Adds an instance of type Genome to the end of this GenomeCollection.
		/// </summary>
		/// <param name="value">
		/// The Genome to be added to the end of this GenomeCollection.
		/// </param>
		public virtual void Add(Genome value)
		{
			this.List.Add(value);
		}

		/// <summary>
		/// Determines whether a specfic Genome value is in this GenomeCollection.
		/// </summary>
		/// <param name="value">
		/// The Genome value to locate in this GenomeCollection.
		/// </param>
		/// <returns>
		/// true if value is found in this GenomeCollection;
		/// false otherwise.
		/// </returns>
		public virtual bool Contains(Genome value)
		{
			return this.List.Contains(value);
		}

		/// <summary>
		/// Return the zero-based index of the first occurrence of a specific value
		/// in this GenomeCollection
		/// </summary>
		/// <param name="value">
		/// The Genome value to locate in the GenomeCollection.
		/// </param>
		/// <returns>
		/// The zero-based index of the first occurrence of the _ELEMENT value if found;
		/// -1 otherwise.
		/// </returns>
		public virtual int IndexOf(Genome value)
		{
			return this.List.IndexOf(value);
		}

		/// <summary>
		/// Inserts an element into the GenomeCollection at the specified index
		/// </summary>
		/// <param name="index">
		/// The index at which the Genome is to be inserted.
		/// </param>
		/// <param name="value">
		/// The Genome to insert.
		/// </param>
		public virtual void Insert(int index, Genome value)
		{
			this.List.Insert(index, value);
		}

		/// <summary>
		/// Gets or sets the Genome at the given index in this GenomeCollection.
		/// </summary>
		public virtual Genome this[int index]
		{
			get
			{
				return (Genome) this.List[index];
			}
			set
			{
				this.List[index] = value;
			}
		}

		/// <summary>
		/// Removes the first occurrence of a specific Genome from this GenomeCollection.
		/// </summary>
		/// <param name="value">
		/// The Genome value to remove from this GenomeCollection.
		/// </param>
		public virtual void Remove(Genome value)
		{
			this.List.Remove(value);
		}

		/// <summary>
		/// Type-specific enumeration class, used by GenomeCollection.GetEnumerator.
		/// </summary>
		public class Enumerator: System.Collections.IEnumerator
		{
			private System.Collections.IEnumerator wrapped;

			public Enumerator(GenomeCollection collection)
			{
				this.wrapped = ((System.Collections.CollectionBase)collection).GetEnumerator();
			}

			public Genome Current
			{
				get
				{
					return (Genome) (this.wrapped.Current);
				}
			}

			object System.Collections.IEnumerator.Current
			{
				get
				{
					return (Genome) (this.wrapped.Current);
				}
			}

			public bool MoveNext()
			{
				return this.wrapped.MoveNext();
			}

			public void Reset()
			{
				this.wrapped.Reset();
			}
		}

		/// <summary>
		/// Returns an enumerator that can iterate through the elements of this GenomeCollection.
		/// </summary>
		/// <returns>
		/// An object that implements System.Collections.IEnumerator.
		/// </returns>        
		public new virtual GenomeCollection.Enumerator GetEnumerator()
		{
			return new GenomeCollection.Enumerator(this);
		}

		#region Sorting Methods
		public void Sort()
		{
			InnerList.Sort();			
		}

		public void Sort(IComparer comparer)
		{
			InnerList.Sort(comparer);
		}

		public void Sort(int index, int count, IComparer comparer)
		{
			InnerList.Sort(index, count, comparer);
		}
		#endregion
	}
}
