using System;
using System.Runtime.InteropServices;
using GeneticAlgorithms;
using GeneticAlgorithms.Binary;

namespace Example1
{
	public class SimpleEvaluator : IEvaluateGenome
	{
		#region IEvaluateGenome Members
		public double Eval(Genome candidate)
		{			
			SimpleSolution sol = (SimpleSolution)((BinaryGenome)candidate).GetObject();
			
			// fitness is simply a larger number:
			// what I've done here is illustrate the fitness as a percent
			// of the highest possible fitness (which is int.MaxValue * 3):
			return 100 * (((double)sol.value1) + ((double)sol.value2) + ((double)sol.value3)) / (((double)int.MaxValue)* 3);
		}
		#endregion
	}
}
