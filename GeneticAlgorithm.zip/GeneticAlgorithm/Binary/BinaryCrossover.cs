using System;
using System.Collections;

namespace GeneticAlgorithms.Binary
{
	/// <summary>
	/// Summary description for BinaryCrossover.
	/// </summary>
	public class BinaryCrossover : ICrossover
	{
		public BinaryCrossover()
		{

		}

		private double _crossoverP=0.25;
		public double CrossoverProbability
		{
			get
			{
				return _crossoverP;
			}
			set
			{
				_crossoverP=value;
			}
		}

		private double _mutationP=0.008;
		public double MutationProbability
		{
			get
			{
				return _mutationP;
			}
			set
			{
				_mutationP=value;
			}
		}

		private BinaryCrossoverMode _mode=BinaryCrossoverMode.Fast;
		public BinaryCrossoverMode CrossoverMode
		{
			get
			{
				return _mode;
			}
			set
			{
				_mode=value;
			}
		}

		public virtual Genome Crossover(Genome first, Genome second)
		{
			BinaryGenome firstB = (BinaryGenome)first;
			BinaryGenome secondB = (BinaryGenome)second;
			
			// cross over this data with the mate's data:
			BitArray we = firstB.Bits;
			BitArray they = secondB.Bits;
			double d=0;

			switch(_mode)
			{
				case BinaryCrossoverMode.Full : 
					for(int i=0;i<we.Length;i++)
					{
						d=GeneticAlgorithmUtility.RandomProvider.NextDouble();
						// do we cross over the mate's value?
						if(d<=_crossoverP)
							we[i] = they[i];

						d=GeneticAlgorithmUtility.RandomProvider.NextDouble();
						// do we mutate this bit?
						if(d<=_mutationP)
							we[i]=!we[i];
					}
					break;					
				case BinaryCrossoverMode.Fast :
					
					//					  Fast mode reduces calculation, but is arguably a less effective way to select the crossover and mutation random points.					  
					 
					int index=0;
					double lengthDouble = secondB.Bits.Length;
					// determines the number of bits to be crossed over:
					int crossCount=(int)
						((_crossoverP * lengthDouble)
						+ ((_crossoverP * lengthDouble)/4 * (GeneticAlgorithmUtility.RandomProvider.NextDouble()-0.5)));
										

					int mutateCount = (int)
						((_mutationP * lengthDouble)
						+ ((_mutationP * lengthDouble)/4 * (GeneticAlgorithmUtility.RandomProvider.NextDouble()-0.5)));

					int loopCount = (crossCount>mutateCount ? crossCount : mutateCount);

					for(int i=0;i<loopCount;i++)
					{
						if(i<=crossCount)
						{
							index = GeneticAlgorithmUtility.RandomProvider.Next(we.Length);
							we[index] = they[index];
						}

						if(i<=mutateCount)
						{
							index = GeneticAlgorithmUtility.RandomProvider.Next(we.Length);
							we[index]=!we[index];
						}
					}
					break;
				case BinaryCrossoverMode.Hyper :
					index=0;
					lengthDouble = secondB.Bits.Length;
					// determines the number of bits to be crossed over:
					crossCount=(int)
						((_crossoverP * lengthDouble) + ((_crossoverP * lengthDouble) * GeneticAlgorithmUtility.RandomProvider.NextDouble() * 1.25d));

					mutateCount = (int)
						((_mutationP * lengthDouble) + ((_mutationP * lengthDouble) * GeneticAlgorithmUtility.RandomProvider.NextDouble() * 2.0d));

					loopCount = (crossCount>mutateCount ? crossCount : mutateCount);

					for(int i=0;i<loopCount;i++)
					{
						if(i<=crossCount)
						{							
							index = GeneticAlgorithmUtility.RandomProvider.Next(we.Length);
							we[index] = they[index];
						}

						if(i<=mutateCount)
						{
							index = GeneticAlgorithmUtility.RandomProvider.Next(we.Length);
							we[index]=!we[index];
						}
					}
					break;
			}

			firstB.Bits = we;
			return (Genome)firstB;
		}
	}
}
