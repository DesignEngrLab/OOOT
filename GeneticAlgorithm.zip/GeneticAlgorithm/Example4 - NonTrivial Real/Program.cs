using System;
using GeneticAlgorithms;
using GeneticAlgorithms.Real;

namespace Example4___NonTrivial_Real
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Program
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			GeneticAlgorithm ga = new GeneticAlgorithm();
			
			ga.Crossover = new RealCrossover();
			ga.GenomeFactory = new RealGenomeFactory(-5.12, 5.12, 15);
			ga.Selector = new WeightedSelector(ga.Genomes);
			ga.Crossover.CrossoverProbability = 0.2;
			ga.Crossover.MutationProbability = 0.015;

			ga.NewGlobalBest += new GeneticAlgorithmEventHandler(onNewGBest);

			ga.Evaluator = new NonTrivialEvaluator();
			((NonTrivialEvaluator)ga.Evaluator).FitnessMode = FitnessFunctionMode.Rastrigrin;


			ga.CreateGenomes(12);
			ExitConditions whenToQuit = new ExitConditions();
			whenToQuit.Duration = new TimeSpan(0, 0, 20);
			//whenToQuit.Generations = 100000;
			//whenToQuit.FitnessGoal=99.5; // can't get higher then 100% of the max score possible!

			Counter clock = new Counter();
			clock.Start();
			RealGenome maxima = (RealGenome)ga.FindOptima(whenToQuit);
			clock.Stop();

			Console.WriteLine(maxima.Fitness.ToString("n"));
			Console.WriteLine(maxima.ToString());
			Console.WriteLine("Time: {0:n}\tGenerations: {1}", clock.Seconds, ga.GenerationCount);			
			Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		}

		public static void onNewGBest(GeneticAlgorithm sender, EventArgs args)
		{
			Console.WriteLine("New GBest: {0}\t\t Generation {1}", sender.Genomes[sender.Genomes.Count-1].Fitness, sender.GenerationCount);
		}
	}
}
