using System;
using GeneticAlgorithms;

namespace GeneticAlgorithms.Real
{
	/// <summary>
	/// Summary description for RealCrossover.
	/// </summary>
	public class RealCrossover : ICrossover
	{
		public RealCrossover()
		{

		}
		
		private double _crossoverP=0.25;
		public double CrossoverProbability
		{
			get
			{
				return _crossoverP;
			}
			set
			{
				_crossoverP=value;
			}
		}

		private double _mutationP=0.008;
		public double MutationProbability
		{
			get
			{
				return _mutationP;
			}
			set
			{
				_mutationP=value;
			}
		}

		private double _mutationFactor=0.25;
		/// <summary>
		/// MutationFactor is the multiplier that the random mutation should be scaled up or down.  For example
		/// a factor of 0.5 means that the mutation will be between 0 and 1/2 of the full range between min and max 
		/// possible values.
		/// </summary>
		public double MutationFactor
		{
			get
			{
				return _mutationFactor;
			}
			set
			{
				_mutationFactor=value;
			}
		}

		protected double valueDeltaCoef=0;
		public virtual Genome Crossover(Genome first, Genome second)
		{
			RealGenome firstR = (RealGenome)first;
			RealGenome secondR = (RealGenome)second;
			double d=0;

			if(valueDeltaCoef==0)
				valueDeltaCoef = (firstR.MaxValue-firstR.MinValue) * _mutationFactor;

			for(int g=0;g<firstR.Length;g++)
			{
				d=GeneticAlgorithmUtility.RandomProvider.NextDouble();
				// do we cross over the mate's value?
				if(d<=_crossoverP)
					firstR[g] = secondR[g];

				d=GeneticAlgorithmUtility.RandomProvider.NextDouble();
				// do we mutate this bit?
				if(d<=_mutationP)
					firstR[g] += valueDeltaCoef*(GeneticAlgorithmUtility.RandomProvider.NextDouble()-0.5);
			}

         return first;
		}

	}
}
