using System;
using GeneticAlgorithms;
using GeneticAlgorithms.Real;

namespace Example4___NonTrivial_Real
{
	/// <summary>
	/// Summary description for NonTrivialEvaluator.
	/// </summary>
	public class NonTrivialEvaluator : IEvaluateGenome
	{
		public FitnessFunctionMode FitnessMode=FitnessFunctionMode.Spherical;

		public NonTrivialEvaluator()
		{
			double fitness = 0;
		}
		#region IEvaluateGenome Members

		public double Eval(Genome candidate)
		{
			RealGenome realGenome = (RealGenome)candidate;

			double fitness = 0;

			switch(FitnessMode)
			{
				case FitnessFunctionMode.Spherical :
					for(int i=0;i<realGenome.Length;i++)
					{
						fitness -= Math.Pow(realGenome[i], 2);
					}
					break;
				case FitnessFunctionMode.Rosenbrock :
					for(int i=0;i<realGenome.Length-1;i++)
					{
						fitness -= (100d * Math.Pow(Math.Pow((realGenome[i+1] - realGenome[i]), 2), 2) + Math.Pow((realGenome[i]-1), 2));
					}
					break;
				case FitnessFunctionMode.Rastrigrin :
					for(int i=0;i<realGenome.Length-1;i++)
					{
						fitness -= 10d + (Math.Pow(realGenome[i], 2)  - 10d * Math.Cos(2d * Math.PI * realGenome[i]));
						//					10.0*n + sum(x(i)^2 - 10.0*cos(2*Pi*x(i)))

					}
					break;
			}

			return fitness;
		}

		#endregion
	}
}
