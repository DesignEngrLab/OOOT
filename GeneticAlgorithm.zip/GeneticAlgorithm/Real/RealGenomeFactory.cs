using System;

namespace GeneticAlgorithms.Real
{
	/// <summary>
	/// Summary description for RealGenomeFactory.
	/// </summary>
	public class RealGenomeFactory : IGenomeFactory
	{
		private double _min;
		private double _max;
		private int _numberOfValues;
		public RealGenomeFactory(double minValue, double maxValue, int numberOfValues)
		{
			_max=maxValue;
			_min=minValue;
         _numberOfValues=numberOfValues;
		}
		#region IGenomeFactory Members


		public Genome CreateGenome(GeneticAlgorithm parent)
		{
			RealGenome newRealGenome = new RealGenome(parent, _numberOfValues);
			newRealGenome.MaxValue = _max;
			newRealGenome.MinValue = _min;
			RandomizeGenome(newRealGenome);
			return newRealGenome;
		}

		#endregion

		public void RandomizeGenome(RealGenome value)
		{
			for(int i=0;i<value.Length;i++)
			{
				value[i] = (GeneticAlgorithmUtility.RandomProvider.NextDouble() * (_max-_min)) + _min;
			}
		}

	}
}
