using System;

namespace GeneticAlgorithms
{
	public enum BinaryCrossoverMode
	{
		Fast,
		Full,
		Hyper
	}
}
