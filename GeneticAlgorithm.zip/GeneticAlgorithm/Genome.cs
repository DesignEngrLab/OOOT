using System;
using System.Collections;

namespace GeneticAlgorithms
{
	abstract public class Genome : IComparable
	{
		protected GeneticAlgorithm Parent;
		protected Genome(GeneticAlgorithm parent)
		{
			Parent=parent;
		}
        
		private double _fitness=double.MinValue;
		public double Fitness
		{
			get
			{
				return _fitness;
			}
			set
			{
				_fitness=value;
			}
		}

		#region IComparable Members
		public int CompareTo(object obj)
		{			
			Genome compared=(Genome)obj;
			if(this.Fitness<compared.Fitness)
				return -1;
			else if(this.Fitness>compared.Fitness)
				return 1;
			else
				return 0;
		}
		#endregion
	}
}
