using System;

namespace GeneticAlgorithms
{
	/// <summary>
	/// ExitCondition is an instance class that is used to describe the conditions that signify
	/// a GeneticAlgorithm's search process should exit.
	/// 
	/// You can exit a search based on time, number of generations or upon reaching a fitness goal.
	/// </summary>
	public class ExitConditions
	{
		public ExitConditions()
		{

		}

		/// <summary>
		/// Examines the GeneticAlgorithm passed to it, to see if it is time to exit.
		/// </summary>
		/// <param name="gaToEvaluate"></param>
		/// <returns></returns>
		public virtual bool DoesContinue(GeneticAlgorithm gaToEvaluate)
		{
			return (DateTime.Now-gaToEvaluate.StartTime)<Duration
						&& gaToEvaluate.GenerationCount<Generations
						&& gaToEvaluate.Genomes[gaToEvaluate.Genomes.Count-1].Fitness<FitnessGoal;
		}

		private TimeSpan _duration=new TimeSpan(long.MaxValue);
		public virtual TimeSpan Duration
		{
			get
			{
				return _duration;
			}
			set
			{
				_duration=value;
			}
		}

		private int _generations=int.MaxValue;
		public virtual int Generations
		{
			get
			{
				return _generations;
			}
			set
			{
				_generations=value;
			}
		}

		private double _fitnessGoal=double.MaxValue;
		public virtual double FitnessGoal
		{
			get
			{
				return _fitnessGoal;
			}
			set
			{
				_fitnessGoal=value;
			}
		}
	}
}
