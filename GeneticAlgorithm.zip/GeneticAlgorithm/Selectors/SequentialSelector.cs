using System;

namespace GeneticAlgorithms
{
	public class Sequential : IGenomeSelector
	{
		public Sequential(GenomeCollection genomes)
		{
			_genomes=genomes;
		}

		#region IGenomeSelector Members
		private GenomeCollection _genomes;
		public GenomeCollection Genomes
		{
			get
			{
				return _genomes;
			}
			set
			{
				_genomes=value;
			}
		}

      private int _currentIndex=0;
		public Genome Select()
		{
			// return with in the Count, and increment index:
			return _genomes[(_currentIndex++) % _genomes.Count];
		}
		
		public void OnNewGeneration(object sender, EventArgs args)
		{
			// if subscribed, this will reset the count:
         _currentIndex=0;
		}
		#endregion
	}
}
