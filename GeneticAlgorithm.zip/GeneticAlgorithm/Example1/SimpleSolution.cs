using System;
using System.Runtime.InteropServices;

namespace Example1
{
	[StructLayout(LayoutKind.Sequential)]
	public class SimpleSolution
	{
		public int value1;
		public int value2;
		public int value3;

		public override string ToString()
		{
			return value1.ToString("n") + " | " + value2.ToString("n") + " | " + value3.ToString("n"); //  + " | " + value3 + " | " + value4;// + " | " + value5 + " | " + value6;
		}
	}
}
